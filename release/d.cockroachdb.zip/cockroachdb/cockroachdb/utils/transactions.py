import time
import random
import logging

from psycopg2 import Error
from psycopg2.errors import SerializationFailure


def run_transaction(conn, op, max_retries=3):
    """
    Execute the operation *op(conn)* retrying serialization failure.

    If the database returns an error asking to retry the transaction, retry it
    *max_retries* times before giving up (and propagate it).
    """
    # leaving this block the transaction will commit or rollback
    # (if leaving with an exception)
    with conn:
        for retry in range(1, max_retries + 1):
            try:
                op(conn)

                # If we reach this point, we were able to commit, so we break
                # from the retry loop.
                return

            except SerializationFailure as e:
                # This is a retry error, so we roll back the current
                # transaction and sleep for a bit before retrying. The
                # sleep time increases for each failed transaction.
                logging.debug("-----------------------------------------")
                logging.debug("got error: %s", e)
                conn.rollback()
                logging.debug(
                    f"EXECUTE SERIALIZATION_FAILURE BRANCH : retried {retry} times"
                )
                sleep_ms = (2 ** retry) * 0.1 * (random.random() + 0.5)
                logging.debug("Sleeping %s seconds", sleep_ms)
                logging.debug("-----------------------------------------")
                time.sleep(sleep_ms)

            except Error as e:
                logging.debug("-----------------------------------------")
                logging.debug("got error: %s", e)
                logging.debug(
                    f"EXECUTE NON-SERIALIZATION_FAILURE BRANCH : retried {retry} times"
                )
                logging.debug("-----------------------------------------")

        logging.debug(f"Transaction did not succeed after {max_retries} retries")
        raise ValueError(f"Transaction did not succeed after {max_retries} retries")


def test_retry_loop(conn):
    """
    Cause a seralization error in the connection.

    This function can be used to test retry logic.
    """
    with conn.cursor() as cur:
        # The first statement in a transaction can be retried transparently on
        # the server, so we need to add a dummy statement so that our
        # force_retry() statement isn't the first one.
        cur.execute("SELECT now()")
        cur.execute("SELECT crdb_internal.force_retry('1s'::INTERVAL)")
    logging.debug("test_retry_loop(): status message: %s", cur.statusmessage)
